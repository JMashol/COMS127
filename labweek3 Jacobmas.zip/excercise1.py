import math


import math
# Jacob Mashol 9/12/22
# Lab Week 3 Excercise 1

a = int(input("input length of a: ")) 
b = int(input("input length of b: ")) 
c = int(input("input length of c: ")) 



s = (a + b + c)/2

area = pow((s*(s-a)*(s-b)*(s-c)),1/2) 

print("the area of a triangle in {0}".format(area)) 