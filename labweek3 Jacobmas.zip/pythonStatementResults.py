# Statement: min(1,2,3,4,5) ==7%2
print("Statement: min(1,2,3,4,5) ==7%2")
#intial hand computer answer: true 
print("hand computer answer: True")
#computer generated answer : true 
print("computer genrated answer: true")
print()

# Statement: float(round(10.4,0))
print("Statement: float(round(10.4,0))")
#intial hand computer answer: true  
print("hand computer answer: True")
#computer generated answer : true 
print("computer genrated answer: true")
print()

# Statement:  pow(2,-2) == pow(2,.25)
print("Statement: pow(2,-2) == pow(2,.25)")
#intial hand computer answer: true 
print("hand computer answer: True")
#computer generated answer : true 
print("computer genrated answer: true")
print()

# Statement: pow(float(round(3.4,0)),float(round(3.4,0)))
print("Statement: pow(float(round(3.4,0)),float(round(3.4,0)))")
#intial hand computer answer: true
print("hand computer answer: True")
#computer generated answer : true 
print("computer genrated answer: true")
print()

# Statement: pow(max(1,2,3),min(4,5,6))
print("Statement: pow(max(1,2,3),min(4,5,6))")
#intial hand computer answer: true
print("hand computer answer: True")
#computer generated answer : true 
print("computer genrated answer: true")
print()