# Jacob Mashol 9/12/22
# Lab Week 3 Excercise 4

base = int(input("Enter the base : "))
height = int(input("Enter the height: "))
area = int((base * height )/2)
print("the area of the triangle is {0} ".format(area)) 