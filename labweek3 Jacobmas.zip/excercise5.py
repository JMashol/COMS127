class1 = input("Input the name of Class1: ")
grade1= int(input("enter grade: "))

class2 = input("Input the name of Class2: ")
grade2= int(input("enter grade: "))

class3 = input("Input the name of Class3: ")
grade3= int(input("enter grade: ")) 

class4 = input("Input the name of Class4: ")
grade4= int(input("enter grade: "))

average = ((grade1 + grade2 + grade3 + grade4) /4)

print("The Average {0}, {1}, {2}, and {3} is {4}".format(class1, class2, class3, class4,average))