# Jacob Mashol 9/12/22
# Lab Week 3 Excercise 3

a = int(input("Enter the interger for a: "))
b = int(input("Enter the interger for b: "))
c = int(input("Enter the interger for c: "))

if (c != 0):
    if(a != c): 
        print("The sum of a, b and, c is", a + b + c)
        print(" modulus of a mod c is", a%c)
        X = c - a 
        y = c / a 
        print(y)
        print((a + b + c)/3) 

else: 
    print(" wronng input a must differ from c and c must not equal zero")
     

     