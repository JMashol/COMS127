import math
# Jacob Mashol 9/12/22
# Lab Week 3 Excercise 2

radius = float(input("Radius of a sphere: "))
area = ((4)*(math.pi)*(pow(radius,3)))
volume = (((4)*(math.pi)*(pow(radius,3)))/3)

print("Area of sphere is {0} and volume of sphere is {1}".format(radius,3)) 